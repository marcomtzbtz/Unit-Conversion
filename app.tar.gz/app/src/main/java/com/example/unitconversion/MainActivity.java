package com.example.unitconversion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Spinner magnitud = (Spinner) findViewById(R.id.spinner_Magnitud);
        final Spinner unidad_inicial = (Spinner) findViewById(R.id.spinner_unidadInicial);
        final Spinner unidad_a_convertir = (Spinner) findViewById(R.id.spinner_unidadAConvertir);

        final EditText unidad = (EditText) findViewById(R.id.editext_unidadNumerica);

        final TextView resultado = (TextView) findViewById(R.id.text_Resultado);

        final ArrayAdapter<CharSequence> adapter_magnitud = ArrayAdapter.createFromResource(this,
                R.array.array_magnitudes, android.R.layout.simple_spinner_item);

        final ArrayAdapter<CharSequence> adapter_longitud = ArrayAdapter.createFromResource(this,
                R.array.longitud, android.R.layout.simple_spinner_item);

        final ArrayAdapter<CharSequence> adapter_masa = ArrayAdapter.createFromResource(this,
                R.array.masa, android.R.layout.simple_spinner_item);

        final ArrayAdapter<CharSequence> adapter_temperatura = ArrayAdapter.createFromResource(this,
                R.array.temperatura, android.R.layout.simple_spinner_item);

        final ArrayAdapter<CharSequence> adapter_tiempo = ArrayAdapter.createFromResource(this,
                R.array.tiempo, android.R.layout.simple_spinner_item);

        magnitud.setAdapter(adapter_magnitud);

        unidad.setText("0");

        magnitud.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 0:
                        unidad_inicial.setAdapter(adapter_longitud);
                        unidad_a_convertir.setAdapter(adapter_longitud);
                        break;

                    case 1:
                        unidad_inicial.setAdapter(adapter_masa);
                        unidad_a_convertir.setAdapter(adapter_masa);
                        break;

                    case 2:
                        unidad_inicial.setAdapter(adapter_tiempo);
                        unidad_a_convertir.setAdapter(adapter_tiempo);
                        break;

                    case 3:
                        unidad_inicial.setAdapter(adapter_temperatura);
                        unidad_a_convertir.setAdapter(adapter_temperatura);
                        break;

                    default:
                        Toast toast = Toast.makeText(getApplicationContext(), "Opción no valida", Toast.LENGTH_LONG);
                        toast.show();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        unidad_inicial.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                float valor_convertido = convertir(magnitud.getSelectedItem().toString(), unidad_inicial.getSelectedItem().toString(),
                        unidad_a_convertir.getSelectedItem().toString(), checarValor(unidad.getText().toString()));
                resultado.setText(Float.toString(valor_convertido));

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        unidad_a_convertir.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                float valor_convertido = convertir(magnitud.getSelectedItem().toString(), unidad_inicial.getSelectedItem().toString(),
                        unidad_a_convertir.getSelectedItem().toString(), checarValor(unidad.getText().toString()));
                resultado.setText(Float.toString(valor_convertido));

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        unidad.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                float valor_convertido = convertir(magnitud.getSelectedItem().toString(), unidad_inicial.getSelectedItem().toString(),
                        unidad_a_convertir.getSelectedItem().toString(), checarValor(unidad.getText().toString()));
                resultado.setText(Float.toString(valor_convertido));

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }

    public float checarValor(String valor_EditText){

        if (valor_EditText == null || valor_EditText.isEmpty()){
            return 0;
        }

        return Float.parseFloat(valor_EditText);

    }

    public float convertir(String magnitud, String unidad_inicial, String unidad_final, float valor){

        float resultado = valor;

        switch (magnitud){
            case "Longitud":
                Conversiones conv_long = new Conversiones();
                resultado = conv_long.convertir_longitud(unidad_inicial, unidad_final, valor);
                break;

            case "Masa":
                resultado = new Conversiones().convertir_masa(unidad_inicial, unidad_final, valor);
                break;
            case "Tiempo":
                resultado = new Conversiones().convertir_tiempo(unidad_inicial, unidad_final, valor);
                break;
            case "Temperatura":
                resultado = new Conversiones().convertir_temperatura(unidad_inicial, unidad_final, valor);
                break;
            default:
                break;
        }

        return resultado;
    }

}