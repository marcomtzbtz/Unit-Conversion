package com.example.unitconversion;

public class Conversiones {

    public float convertir_longitud(String unidad_inicial, String unidad_a_convertir, float valor_inicial){
        if (unidad_inicial.equals(unidad_a_convertir)){
            return valor_inicial;
        }

        float unidad_a_metro = 0;
        float resultado = 0;

        switch (unidad_inicial){
            case "Milímetro":
                unidad_a_metro = valor_inicial / 1000;
                break;

            case "Centímetro":
                unidad_a_metro = valor_inicial / 100;
                break;

            case "Kilómetro":
                unidad_a_metro = valor_inicial * 1000;
                break;

            case "Pulgada":
                unidad_a_metro = valor_inicial / 39.37f;
                break;

            case "Pie":
                unidad_a_metro = valor_inicial / 3.281f;
                break;

            case "Milla":
                unidad_a_metro = valor_inicial * 1609f;
                break;

            case "Yarda":
                unidad_a_metro = valor_inicial / 1.094f;
                break;

            default:
                unidad_a_metro = valor_inicial;
                break;
        }

        switch (unidad_a_convertir){

            case "Milímetro":
                resultado = unidad_a_metro * 1000;
                break;

            case "Centímetro":
                resultado = unidad_a_metro * 100;
                break;

            case "Kilómetro":
                resultado = unidad_a_metro / 1000;
                break;

            case "Pulgada":
                resultado = unidad_a_metro * 39.37f;
                break;

            case "Pie":
                resultado = unidad_a_metro * 3.281f;
                break;

            case "Milla":
                resultado = unidad_a_metro / 1609f;
                break;

            case "Yarda":
                resultado = unidad_a_metro * 1.094f;
                break;

            default:
                resultado = unidad_a_metro;
                break;

        }

        return resultado;
    }

    public float convertir_masa(String unidad_inicial, String unidad_a_convertir, float valor_inicial){

        if (unidad_inicial.equals(unidad_a_convertir)){
            return valor_inicial;
        }

        float unidad_en_gramo = 0;
        float resultado = 0;

        switch (unidad_inicial){
            case "Milígramo":
                unidad_en_gramo = valor_inicial / 1000;
                break;

            case "Kilógramo":
                unidad_en_gramo = valor_inicial * 1000;
                break;

            case "Tonelada":
                unidad_en_gramo = valor_inicial * 1E6f;
                break;

            case "Onza":
                unidad_en_gramo = valor_inicial * 28.35f;
                break;

            case "Libra":
                unidad_en_gramo = valor_inicial * 454f;
                break;

            case "Stone":
                unidad_en_gramo = valor_inicial * 6350f;
                break;

            default:
                unidad_en_gramo = valor_inicial;
                break;
        }

        switch (unidad_a_convertir){

            case "Milígramo":
                resultado = unidad_en_gramo * 1000;
                break;

            case "Kilógramo":
                resultado = unidad_en_gramo / 1000;
                break;

            case "Tonelada":
                resultado = unidad_en_gramo / 1e6f;
                break;

            case "Onza":
                resultado = unidad_en_gramo / 28.35f;
                break;

            case "Libra":
                resultado = unidad_en_gramo / 454f;
                break;

            case "Stone":
                resultado = unidad_en_gramo / 6350f;
                break;

            default:
                resultado = unidad_en_gramo;
                break;

        }

        return resultado;
    }

    public float convertir_temperatura (String unidad_inicial, String unidad_a_convertir, float valor_inicial){

        if (unidad_inicial.equals(unidad_a_convertir))
            return valor_inicial;

        float resultado = 0;

        switch (unidad_inicial){
            case "Celcius":
                if (unidad_a_convertir.equals("Kelvin"))
                    resultado = valor_inicial + 273.15f;
                else
                    resultado = ((valor_inicial * 9) / 5) + 32;
                break;
            case "Fahrenheit":
                if (unidad_a_convertir.equals("Kelvin"))
                    resultado = ((valor_inicial - 32) * 5 ) / 9 +273.15f;
                else
                    resultado = ((valor_inicial - 32) * 5 ) / 9;
                break;
            case "Kelvin":
                if (unidad_a_convertir.equals("Celcius"))
                    resultado = valor_inicial - 273.15f;
                else
                    resultado = (valor_inicial - 273.15f) * 9 / 5 + 32;
                break;
            default:
                break;
        }

        return resultado;
    }

    public float convertir_tiempo (String unidad_inicial, String unidad_a_convertir, float valor_inicial) {

        if (unidad_inicial.equals(unidad_a_convertir))
            return valor_inicial;

        float resultado = 0;
        float segundo = 0;

        switch (unidad_inicial){
            case "Minuto":
                segundo = valor_inicial * 60;
                break;
            case "Hora":
                segundo = valor_inicial * 3600;
                break;
            case "Día":
                segundo = valor_inicial * 86400;
                break;
            case "Semana":
                segundo = valor_inicial * 604800;
                break;
            case "Mes":
                segundo = valor_inicial * 2.628e+6f;
                break;
            case "Año":
                segundo = valor_inicial * 3.154e+7f;
                break;
            default:
                segundo = valor_inicial;
                break;
        }

        switch (unidad_a_convertir){
            case "Minuto":
                resultado = segundo / 60;
                break;
            case "Hora":
                resultado = segundo / 3600;
                break;
            case "Día":
                resultado = segundo / 86400;
                break;
            case "Semana":
                resultado = segundo / 604800;
                break;
            case "Mes":
                resultado = segundo / 2.628e+6f;
                break;
            case "Año":
                resultado = segundo / 3.154e+7f;
                break;
            default:
                resultado = segundo;
                break;
        }

        return resultado;
    }

}
